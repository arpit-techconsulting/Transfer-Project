//
//  GridCollectionViewCell.swift
//  Memory
//
//  Created by Serena Roderick on 9/5/24.
//

import UIKit
import Combine


class GridCollectionViewCell: UICollectionViewCell {
    let gameVM = GameViewModel()
    var isPlayingCancellable: AnyCancellable?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func showImage(itemIndex: Int) {
            isPlayingCancellable = gameVM.$isPlaying.sink(receiveValue: { [weak self] isPlaying in
                guard let self = self else { return }
                
                print(isPlaying)
                if isPlaying {
                    let imageView = UIImageView(image: UIImage(named: self.gameVM.imgNames[itemIndex]))
                    self.addSubview(imageView)
                    imageView.translatesAutoresizingMaskIntoConstraints = false
                    imageView.frame = self.contentView.bounds
            }
        })
    }
}
